import requests
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views import View
# from django.core.mail import send_mail
# from .forms import RegistrationForm, LoginForm
from django.contrib import messages


class IndexView(View):
    def get(self, request):
        return render(request, 'index.html')


class AboutView(View):
    def get(self, request):
        return render(request, 'about.html')


class ContactView(View):
    def get(self, request):
        return render(request, 'contact.html')


class CartView(View):
    def get(self, request):
        return render(request, 'cart.html')


class CheckoutView(View):
    def get(self, request):
        return render(request, 'checkout.html')


class ShopView(View):
    def get(self, request):
        return render(request, 'shop.html')


class ThankyouView(View):
    def get(self, request):
        return render(request, 'thankyou.html')


class ServiceView(View):
    def get(self, request):
        return render(request, 'services.html')


class BlogView(View):
    def get(self, request):
        return render(request, 'blog.html')


class LoginView(View):
    def get(self, request):
        return render(request, 'auth/login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        url = "http://127.0.0.2:8007/client/login/"
        data = {
            "username": username,
            "password": password,
        }

        if username and password:
            response = requests.post(url, json=data)

            try:
                response.raise_for_status()  # Raise an error for bad responses
                token = response.json().get('token')  # Adjust based on your API response

                if token:
                    # Store token in session or cookie if needed
                    request.session['auth_token'] = token
                    messages.success(request, "Login successful!")  # Add a success message
                    return redirect('index')  # Redirect to the URL name for index
                else:
                    error_message = "Login failed. Please check your username and password."
                    return render(request, 'auth/login.html', {'message': error_message, 'data': data})
            except requests.exceptions.HTTPError:
                error_message = "An error occurred with the login request."
                return render(request, 'auth/login.html', {'message': error_message, 'data': data})
            except (ValueError, KeyError):
                error_message = "Error processing FastAPI response."
                return render(request, 'auth/login.html', {'message': error_message, 'data': data})
        else:
            error_message = 'Both fields are required.'
            return render(request, 'auth/login.html', {'message': error_message, 'data': data})


class RegisterView(View):
    def get(self, request):
        return render(request, 'auth/register.html')

    def post(self, request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        url = "http://127.0.0.2:8007/client/register/"
        data = {
            "first_name": first_name,
            "last_name": last_name,
            "username": username,
            "email": email,
            "phone": phone,
            "password": password,
        }

        if all([first_name, last_name, username, email, phone, password]):
            response = requests.post(url, json=data)

            try:
                response.raise_for_status()  # Raise an error for bad responses
                detail = response.json().get('detail')

                if detail == "email":
                    error_message = 'Email already exists.'
                elif detail == "username":
                    error_message = 'Username already exists.'
                else:
                    return redirect('login')

                # Render the registration page with the error message
                return render(request, 'auth/register.html', {'message': error_message, 'data': data})

            except requests.exceptions.HTTPError:
                error_message = "Kechirasiz xatolik yuz berdi qayta urunib koring."
                return render(request, 'auth/register.html', {'message': error_message, 'data': data})
            except (ValueError, KeyError):
                error_message = "Error processing FastAPI response."
                return render(request, 'auth/register.html', {'message': error_message, 'data': data})
        else:
            error_message = 'All fields are required.'
            return render(request, 'auth/register.html', {'message': error_message, 'data': data})


